package org.arpit.java2blog.algorithm;

public class Response {

    Integer trailingZero;
    Boolean success;
    String message;

    public Response(Integer trailingZero,Boolean success, String message) {
        this.trailingZero = trailingZero;
        this.success = success;
        this.message = message;
    }

}
