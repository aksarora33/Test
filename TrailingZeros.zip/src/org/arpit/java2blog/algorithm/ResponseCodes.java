package org.arpit.java2blog.algorithm;

public enum ResponseCodes {
    //Codes for different scenarios
    //
    SUCCESS,
    IS_EMPTY;
    //etc



}
