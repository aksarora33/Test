package org.arpit.java2blog.algorithm;

public class TrailingZero {

    public static Response countFactorialTrailingZeros(String numStr)
    {
        //Assumption - num should be in valid range
        //Assumption a valid Integer
        //IsNotNull
        //IsNotEmpty
        //IsValidNumber

        ResponseCodes code = isValid(numStr);
        if(!ResponseCodes.SUCCESS.equals(code))
            return new Response(null , false, populateMessage(code));
        Integer num = Integer.valueOf(numStr);
        int countOfZeros=0;
        for(int i=2;i<=num;i++)
        {
            countOfZeros+=countFactorsOf5(i);
        }
        return new Response(countOfZeros,true ,populateMessage(code));
    }

    private static  int countFactorsOf5(int i)
    {
        int count=0;
        while(i%5==0)
        {
            i/=5;
            count++;
        }
        return count;
    }

    public static ResponseCodes isValid(String num){

        if(num.isEmpty())
            return ResponseCodes.IS_EMPTY;


        //Validation for other scenarios



        return ResponseCodes.SUCCESS;
    }

    private static String populateMessage(ResponseCodes code){

        if(ResponseCodes.IS_EMPTY.equals(code))
            return "Input cant be empty";
        if(ResponseCodes.SUCCESS.equals(code))
            return "Success";

        return "Not a valid scenario";
    }

}
