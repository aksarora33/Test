package org.arpit.java2blog.algorithm;
public class FactorialTrailingZeroMain {

    public static void main(String[] args) {

//        String input  = "";
//        TrailingZero.isValid(input);

        Response res = TrailingZero.countFactorialTrailingZeros("29");
        if(res.success)
            System.out.println("Factorial trailing zeroes for 29: "+res.trailingZero);
        else
            System.out.println("Error : " +res.message);
    }

}